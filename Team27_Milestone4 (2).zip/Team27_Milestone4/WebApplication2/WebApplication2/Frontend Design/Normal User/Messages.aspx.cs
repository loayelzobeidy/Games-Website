﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using WebApplication2.Controllers;
using WebApplication2.Exceptions;
namespace WebApplication2.Frontend_Design.Normal_User
{
    public partial class FriendRequests : System.Web.UI.Page
    {
        ProfileController controller;
        protected void Page_Load(object sender, EventArgs e)
        {
            try {
                controller = new ProfileController();
                string email =(string) Session["LoggedinMemberEmail"];
                DataSet ds = controller.getRecievedMessages(email, "Messages");

                GridView1.DataSource = ds;
                GridView1.DataBind();
                lblStatus.InnerText = "Recent Messages Received ";
            }
            catch(EmptyReturnedQueryException )
            {
                lblStatus.InnerText = "No Recent Messages Availabe";
                
            }

   
    
         

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e) // i remove the first coloumn then added it to the end 
        {
         
            TableCell cell = e.Row.Cells[0];
            e.Row.Cells.RemoveAt(0);

            e.Row.Cells.Add(cell);
            e.Row.Cells[5].Width = 200;


        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            FieldSet.Visible = true;
            string ReceiverName = row.Cells[0].Text;
            string ReceiverEmail = row.Cells[2].Text;
            string MessageToReplyOn = row.Cells[4].Text;
            lblMessageToReplyOn.Text = MessageToReplyOn;
            lblMessageToReplyOn.Text = ReceiverName + " : " + MessageToReplyOn;
            Session["receiverEmail"] = ReceiverEmail;


            
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
        
            string senderEmail = (string)Session["LoggedinMemberEmail"];
            DateTime datetime = DateTime.Now;
            string ReceiverEmail =(string) Session["receiverEmail"];

            string MessageText = txtReplyMessage.InnerText;
            if ((!string.IsNullOrEmpty(MessageText)) || (!string.IsNullOrWhiteSpace(MessageText)))
            {
                controller = new ProfileController();
                try
                {
                    int result = controller.SendMessage(senderEmail, ReceiverEmail, datetime, MessageText);
                    if (result == 1)
                    {
                        lblSendMessagestatus.Text = "Message sent Successfully";
                        lblSendMessagestatus.ForeColor = System.Drawing.Color.Green;

                    }

                }
                catch (TransactionFailedException exception)
                {
                    lblSendMessagestatus.Text = exception.Message;
                    lblSendMessagestatus.ForeColor = System.Drawing.Color.Red;
                }
                catch (Exception ex)
                {
                    lblSendMessagestatus.Text = ex.Message;
                    lblSendMessagestatus.ForeColor = System.Drawing.Color.Red;
                }
            }
            else
            {
                lblSendMessagestatus.Text = "You Must type A message ";
            }
        }
    }
}