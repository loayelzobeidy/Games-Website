﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;
using System.Data;
using WebApplication2.Exceptions;

namespace WebApplication2.Frontend_Design.Normal_User
{
    public partial class RecommendGames : System.Web.UI.Page
    {
        GameController controller = new GameController();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                
                string email = (string)Session["LoggedinMemberEmail"];
                DataSet ds = controller.GetAllGames( "Games");

                GridView1.DataSource = ds;
                GridView1.DataBind();
                lblHeader.Text = "Available Games Received ";
            }
            catch (EmptyReturnedQueryException)
            {
                lblHeader.Text = "No  Games Availabe";

            }
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e) // i remove the first coloumn then added it to the end 
        {

            TableCell cell = e.Row.Cells[0];
            e.Row.Cells.RemoveAt(0);

            e.Row.Cells.Add(cell);
          

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            string GameName = row.Cells[0].Text;
            string SenderEmail =(string) Session["LoggedinMemberEmail"];
            string ReceiverEmail = (string)Session["MemberEmail"];
          
            try {
              int RowsAffected=  controller.RecommendGame(SenderEmail, ReceiverEmail, GameName);
                if(RowsAffected == 1)
                {
                    LblStatus.Text = "Recommending Game Completed Successfully";
                }
            }
            catch(Exception ex)
            {
                LblStatus.Text = ex.Message;
            }
        }

    }
}