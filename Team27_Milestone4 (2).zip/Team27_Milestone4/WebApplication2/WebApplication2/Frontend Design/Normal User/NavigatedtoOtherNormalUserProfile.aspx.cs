﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;
namespace WebApplication2.Frontend_Design.Normal_User
{
    public partial class NavigatedtoOtherNormalUserProfile : System.Web.UI.Page
    {
        ProfileController controller;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                controller = new ProfileController();
                string email = (string)Session["MemberEmail"];
                string[] NormalUserProfileData = controller.GetNormalUserProfileData(email);
                lblFirstName.InnerText = NormalUserProfileData[0];
                LblLastName.InnerText = NormalUserProfileData[1];
                LblEmail.InnerText = NormalUserProfileData[2];
                LblMemberType.InnerText = NormalUserProfileData[3];
                LblBirthDate.InnerText = NormalUserProfileData[4];
                LblAge.InnerText = NormalUserProfileData[5];
                lblGameGenre.InnerText = NormalUserProfileData[6];
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
    }
}