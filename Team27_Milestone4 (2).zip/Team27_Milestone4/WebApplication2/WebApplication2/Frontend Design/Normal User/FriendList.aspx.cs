﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;
using System.Data;
using WebApplication2.Exceptions;
namespace WebApplication2.Frontend_Design.Normal_User
{
    public partial class FriendList : System.Web.UI.Page
    {
        ProfileController controller = new ProfileController();
        protected void Page_Load(object sender, EventArgs e)
        {
          

            try
            {

                string email = (string)Session["LoggedinMemberEmail"];
                List<string[]> outputList = controller.getListOfFriendsIadded(email, "Added");
                List<string []> l= controller.getListOfFriendsIadded(email, "Requested");
                outputList.AddRange(l);
                if (outputList.Count != 0)
                {
                    lblHeader.InnerText = "Normal Users Friend Requests";

                    int count = 0;
                    TableRow row = new TableRow();
                    Table1.Rows.Add(row);
                    row.Attributes.Add("style", "background-color:#1C5E55; border:2px solid Black; color:black ");

                    TableCell cell = new TableCell();
                    cell.Text = "First Name";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    cell.Text = "Last Name";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    cell.Text = "Email";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    row.Cells.Add(cell);

                    foreach (string[] OutputRow in outputList)
                    {
                        row = new TableRow();
                        Table1.Rows.Add(row);
                        if (count % 2 == 0)
                        {
                            row.Attributes.Add("style", "background-color:#E3EAEB; border:2px solid Black; color:black ");

                        }
                        else
                        {
                            row.Attributes.Add("style", "background-color:White; border:2px solid Black; color:black ");

                        }
                        string RequestingEmail = OutputRow[2];
                        for (int i = 0; i < 3; i++)
                        {
                            cell = new TableCell();

                            cell.Text = OutputRow[i];
                            row.Cells.Add(cell);

                        }
                        Button btnRemove = new Button();
                        btnRemove.Text = "Remove";
                        btnRemove.CommandName = RequestingEmail;
                        cell = new TableCell();
                        cell.Controls.Add(btnRemove);
                        row.Cells.Add(cell);
                        btnRemove.Command += BtnRemove_Command;

                        Button btnSendMessage = new Button();
                        btnSendMessage.Text = "Send Message";
                        btnSendMessage.CommandName = RequestingEmail;
                        cell = new TableCell();
                        cell.Controls.Add(btnSendMessage);
                        row.Cells.Add(cell);
                        btnSendMessage.Command += BtnSendMessage_Command;

                        Button btnShowProfile = new Button();
                        btnShowProfile.Text = "Show Profile";
                        btnShowProfile.CommandName = RequestingEmail;
                        cell = new TableCell();
                        cell.Controls.Add(btnShowProfile);
                        row.Cells.Add(cell);
                        btnShowProfile.Command += BtnShowProfile_Command;

                        count++;
                    }
                }
                else
                {
                    lblHeader.InnerText = "No Friend Requests Availabel";
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
           

        }
        protected void BtnRemove_Command(object sender, CommandEventArgs e)
        {
            string MyEmail =(string) Session["LoggedinMemberEmail"];
            string unFriendEmail = e.CommandName;
            try {
                controller.removeFriend(MyEmail, unFriendEmail);
                Response.Redirect("~/Frontend Design/Normal User/FriendList.aspx");
            }
            catch(Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
        }

        protected void BtnSendMessage_Command(object sender, CommandEventArgs e)
        {
            FieldSet.Visible = true;
            Session["receiverEmail"] = e.CommandName;
        }

        protected void BtnShowProfile_Command(object sender, CommandEventArgs e)
        {
            Session["MemberEmail"] = e.CommandName;
            Response.Redirect("~/Frontend Design/Normal User/NavigatedtoOtherNormalUserProfile.aspx");
        }

  

        protected void btnSend_Click1(object sender, EventArgs e)
        {
            string senderEmail = (string)Session["LoggedinMemberEmail"];
            DateTime datetime = DateTime.Now;
            string ReceiverEmail = (string)Session["receiverEmail"];

            string MessageText = txtReplyMessage.InnerText;
            if ((!string.IsNullOrEmpty(MessageText)) || (!string.IsNullOrWhiteSpace(MessageText)))
            {
                controller = new ProfileController();
                try
                {
                    int result = controller.SendMessage(senderEmail, ReceiverEmail, datetime, MessageText);
                    if (result == 1)
                    {
                        lblSendMessagestatus.Text = "Message sent Successfully";
                        lblSendMessagestatus.ForeColor = System.Drawing.Color.Green;

                    }

                }
                catch (TransactionFailedException exception)
                {
                    lblSendMessagestatus.Text = exception.Message;
                    lblSendMessagestatus.ForeColor = System.Drawing.Color.Red;
                }
                catch (Exception ex)
                {
                    lblSendMessagestatus.Text = ex.Message;
                    lblSendMessagestatus.ForeColor = System.Drawing.Color.Red;
                }
            }
            else
            {
                lblSendMessagestatus.Text = "You Must type A message ";
            }
        }
    }
}