﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;
namespace WebApplication2.Frontend_Design.Normal_User
{
    public partial class Messages : System.Web.UI.Page
    {
        ProfileController controller = new ProfileController();
        protected void Page_Load(object sender, EventArgs e)
        {
            try {

                string email = (string)Session["LoggedinMemberEmail"];
                List<string[]> outputList = controller.getFriendRequests(email);
                if (outputList.Count != 0)
                {
                    lblHeader.InnerText = "Normal Users Friend Requests";

                    int count = 0;
                    TableRow row = new TableRow();
                    Table1.Rows.Add(row);
                    row.Attributes.Add("style", "background-color:#1C5E55; border:2px solid Black; color:black ");

                    TableCell cell = new TableCell();
                    cell.Text = "First Name";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    cell.Text = "Last Name";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    cell.Text = "Email";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    row.Cells.Add(cell);

                    foreach (string[] OutputRow in outputList)
                    {
                        row = new TableRow();
                        Table1.Rows.Add(row);
                        if (count % 2 == 0)
                        {
                            row.Attributes.Add("style", "background-color:#E3EAEB; border:2px solid Black; color:black ");

                        }
                        else
                        {
                            row.Attributes.Add("style", "background-color:White; border:2px solid Black; color:black ");

                        }
                        string RequestingEmail = OutputRow[2];
                        for (int i = 0; i < 3; i++)
                        {
                            cell = new TableCell();

                            cell.Text = OutputRow[i];
                            row.Cells.Add(cell);

                        }
                        Button btnAccept = new Button();
                        btnAccept.Text = "Accept";
                        btnAccept.CommandName = RequestingEmail;
                        cell = new TableCell();
                        cell.Controls.Add(btnAccept);
                        row.Cells.Add(cell);
                        btnAccept.Command += BtnAccept_Command;

                        Button btnReject = new Button();
                        btnReject.Text = "Reject";
                        btnReject.CommandName = RequestingEmail;
                        cell = new TableCell();
                        cell.Controls.Add(btnReject);
                        row.Cells.Add(cell);
                        btnReject.Command += BtnReject_Command;

                        Button btnShowProfile = new Button();
                        btnShowProfile.Text = "Show Profile";
                        btnShowProfile.CommandName = RequestingEmail;
                        cell = new TableCell();
                        cell.Controls.Add(btnShowProfile);
                        row.Cells.Add(cell);
                        btnShowProfile.Command += BtnShowProfile_Command;

                        count++;
                    }
                }
                else
                {
                    lblHeader.InnerText = "No Friend Requests Availabel";
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
        }

        protected void BtnAccept_Command(object sender, CommandEventArgs e)
        {
            string ReceivingEmail = (string)Session["LoggedinMemberEmail"];
            string RequestingEmail = e.CommandName;
            try {
                controller.AcceptFriend(RequestingEmail, ReceivingEmail);
                Response.Redirect("~/Frontend Design/Normal User/FriendRequests.aspx");
            }
            catch(Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
        }

        protected void BtnReject_Command(object sender, CommandEventArgs e)
        {
            string ReceivingEmail = (string)Session["LoggedinMemberEmail"];
            string RequestingEmail = e.CommandName;
            try
            {
                controller.RejectFriend(RequestingEmail, ReceivingEmail);
                Response.Redirect("~/Frontend Design/Normal User/FriendRequests.aspx");
            }
            catch (Exception ex)
            {
                lblStatus.Text = ex.Message;
            }

        }
        protected void BtnShowProfile_Command(object sender, CommandEventArgs e)
        {
            Session["MemberEmail"] = e.CommandName;
            Response.Redirect("~/Frontend Design/Normal User/NavigatedtoOtherNormalUserProfile.aspx");
        }

    
    }
}