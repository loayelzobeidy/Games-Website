﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication2.Frontend_Design.Community
{
    public partial class Topic : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = (string)Session["topicID"];
            // int idnumber = Int32.Parse(id);

            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("TopicInformation", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@id", id));
            conn.Open();
            using (SqlDataReader rdr = cmd.ExecuteReader())
            {
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        string TopicName = rdr.GetString(rdr.GetOrdinal("title"));
                        string Theme = rdr.GetString(rdr.GetOrdinal("theme"));
                        string By = rdr.GetString(rdr.GetOrdinal("member_email"));
                        string Description = rdr.GetString(rdr.GetOrdinal("description"));



                        lblTopicTitle.InnerText = TopicName;
                        lblTopicTheme.InnerText = Theme;
                        lbldescription.InnerText = Description;
                        linkUserProfile.InnerText = By;





                    }
                }


            }


            SqlCommand cmd2 = new SqlCommand("select * from Topic_Comments_by_members where topic_id='" + id + "'", conn);


            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(cmd2);
            sda.Fill(ds);


            GridView1.DataSource = ds;
            GridView1.DataBind();
            conn.Close();
            conn.Open();


        }

        protected void btnAddComment_Click(object sender, EventArgs e)
        {


            string id = (string)Session["topicID"];
           

            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("sp_Topic_Comment", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@comment", CommentDesc.Value));

        
            string email = (string)Session["LoggedinMemberEmail"];

            cmd.Parameters.Add(new SqlParameter("@email", email));
            cmd.Parameters.Add(new SqlParameter("@id", id));

            conn.Open();


            cmd.ExecuteNonQuery();




        }

        protected void Add_Comment(object sender, EventArgs e)
        {
            CreateComment.Visible = true;
        }




        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            string CommentID = row.Cells[1].Text;
            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("sp_delete_comment_on_topic", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            string Theme = (string)Session["CommunityTheme"];
            string email = (string)Session["LoggedinMemberEmail"];

            cmd.Parameters.Add(new SqlParameter("@id", CommentID));
            cmd.Parameters.Add(new SqlParameter("@email", email));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

        }
    }
}