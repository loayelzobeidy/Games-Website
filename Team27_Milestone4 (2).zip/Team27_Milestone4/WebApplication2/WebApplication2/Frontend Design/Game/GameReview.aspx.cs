﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;


namespace WebApplication2.Frontend_Design.Game
{
    public partial class GameReview : System.Web.UI.Page
    {
        GameController controller = new GameController();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (IsPostBack)
            {
                if (Session["Count"] != null)
                {
                    if ((int)Session["Count"] >= 1)
                    {
                        ShowComments();
                    }
                }
             
            }

            if (!IsPostBack)
            {
                try
                {
                    string ReviewID = (string)Session["ReviewID"];
                    string GameName = (string)Session["GameName"];

                    string[] ReviewData = controller.getReviewData(ReviewID, GameName);
                    lblGameName.InnerText = ReviewData[0];
                    lblReviewedBy.InnerText = ReviewData[1];
                    btnShowProfile.CommandName = ReviewData[1];
                    LblDate.InnerText = ReviewData[2];
                    lblReviewTile.InnerText = ReviewData[3];
                    LblContent.InnerText = ReviewData[4];
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        protected void btnShowComments_Click(object sender, EventArgs e)
        {
            ShowComments();
        }


        public void ShowComments()
        {
            // 3alshan ana fo2 b3ml calling lel method after each postback so i intialize a count to avoid calling
            // this method after the first postback when  show comments button clicked

            if (Session["Count"] == null)
            {
                Session["Count"] = 1;
            }
            else
            {
                int count = (int)Session["Count"];
                Session["Count"] = count++;
            }
            try
            {           
               
             
                string ReviewID = (string)Session["ReviewID"];

                string email = (string)Session["LoggedinMemberEmail"];
                List<string[]> outputList = controller.getCommentsOnReview(ReviewID);
                int count = 0;

                foreach (string[] OutputRow in outputList)
                {
                    TableRow row = new TableRow();
                    Table1.Rows.Add(row);
                    if (count % 2 == 0)
                    {
                        row.Attributes.Add("style", "background-color:#E3EAEB; border:2px solid Black; color:black ");

                    }
                    else
                    {
                        row.Attributes.Add("style", "background-color:White; border:2px solid Black; color:black ");

                    }

                    HtmlGenericControl fieldSet = new HtmlGenericControl("fieldset");
                    fieldSet.Attributes.Add("style", "border: solid 1px black;width:400px");
                    HtmlGenericControl legend = new HtmlGenericControl("legend");
                    legend.Attributes.Add("style", " color:black; font - weight:bold; ");
                    legend.InnerText = OutputRow[0];
                    Label label = new Label();
                    label.Attributes.Add("style", "width:300px ; color:black");
                    label.Text = OutputRow[1];

                  




                    fieldSet.Controls.Add(legend);
                    fieldSet.Controls.Add(label);
                    TableCell cell = new TableCell();
                    cell.Controls.Add(fieldSet);
                    row.Cells.Add(cell);

                    Button btnDelete = new Button();
                    btnDelete.Text = "Delete";
                    btnDelete.CommandName = OutputRow[2];
                    btnDelete.Command += BtnDeleteComment_Command;
                   // btnDelete.Click += new EventHandler(test);
               
                    cell.Controls.Add(btnDelete);


                    count++;
                }
            }


            catch (Exception ex)
            {
                lblCommentsHeader.InnerText = ex.Message;
            }
        }


        protected void BtnAddcomment_Click(object sender, EventArgs e)
        {

            string Comment = TxtComment.InnerText;

            if (string.IsNullOrEmpty(Comment) || string.IsNullOrWhiteSpace(Comment))
            {
                lblCommentStatus.Text = "You Must write a Comment";
                lblCommentStatus.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                string ReviewID = (string)Session["ReviewID"];
                string GameName = (string)Session["GameName"];
                string email = (string)Session["LoggedinMemberEmail"];

                try
                {
                    controller.AddComment(ReviewID, GameName, email, Comment);
                    lblCommentStatus.Text = "Comment Added Successfullly";
                    lblCommentStatus.ForeColor = System.Drawing.Color.Green;
                }
                catch (Exception ex)
                {
                    lblCommentStatus.Text = ex.Message;
                }
            }
        }

        protected void btnShowProfile_Click(object sender, EventArgs e)
        {
            Session["MemberEmail"] = lblReviewedBy.InnerText;
            Response.Redirect("~/Frontend Design/Vrefied Reviewer/NavigatingToVrifiedReviewerProfile.aspx");
        }


        protected void BtnDeleteComment_Command(object sender, CommandEventArgs e)
        {
            try
            {
                string CommentID = e.CommandName;
                int check = controller.DeleteCommentOnReview(CommentID);
                if (check == 1)
                {
                    lblCommentStatus.Text = "Comment Deleted Successfully";
                    lblCommentStatus.ForeColor = System.Drawing.Color.Green;
                    ShowComments();
                }
            }
            catch (Exception ex)
            {
                lblCommentStatus.Text = ex.Message;
                lblCommentStatus.ForeColor = System.Drawing.Color.Red;
            }
        }

       
    }
}