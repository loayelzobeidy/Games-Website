﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;

namespace WebApplication2.Frontend_Design.Game
{
    public partial class ScreenshotsGallary : System.Web.UI.Page
    {
        GameController controller = new GameController();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadImages();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try {
                if (FileUpload1.HasFile)
                {
                    string fileName = FileUpload1.FileName;
                    string gameName = (string)Session["GameName"];
                    int check = controller.AddScreenShot(gameName, fileName);
                    if (check == 1)
                    {
                        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Frontend Design/Game/Screenhots/") + fileName);
                        LblUploadStatus.Text = "Screenshot Uploaded Successfully";
                        LblUploadStatus.ForeColor = System.Drawing.Color.Green;
                    }
                }
            } catch(Exception ex)
            {
                LblUploadStatus.Text = ex.Message;
                LblUploadStatus.ForeColor = System.Drawing.Color.Red;
            }
        }

        private void LoadImages()
        {
            try {
                string gameName = (string)Session["GameName"];
                List<string[]> outputList = controller.GetScreenShotsPath(gameName);

                foreach (string[] row in outputList)
                {
                    string fileName = row[0];
                    Image i = new Image();
                    i.ImageUrl = "~/Frontend Design/Game/Screenhots/" + fileName;
                    i.Height = Unit.Pixel(250);
                    i.Style.Add("padding", "5px");
                    i.Width = Unit.Pixel(250);
                    Panel1.Controls.Add(i);
                }
            }
            catch(Exception ex)
            {
                Lblstatus.Text = ex.Message;
            }
            }

     
    }
        
}