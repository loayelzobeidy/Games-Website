﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;

namespace WebApplication2.Frontend_Design.Game
{
    public partial class GameProfile : System.Web.UI.Page
    {
        GameController controller = new GameController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {

                    string GameNme = (string) Session["GameName"];
                  
                    string[] GameProfileData = controller.GetGameProfileData(GameNme);
                    lblGameName.InnerText = GameProfileData[0];
                    LblAgeLimit.InnerText = GameProfileData[1];
                    LblDevTeam.InnerText = GameProfileData[2];
                    LblRating.InnerText = GameProfileData[3];
                    lblReleaseDate.InnerText = GameProfileData[4];
                    lblType.InnerText = GameProfileData[5];
                    string gameType = GameProfileData[5];

                    GameProfileData = controller.getSpecialGameprofileData(GameNme, gameType);
                    switch (gameType)
                    {
                        case "Action":
                            lblTmp1Header.InnerText = "Sub Genre : ";
                            LblTmp1.InnerText = GameProfileData[0];
                            break;

                        case "Sports":
                            lblTmp1Header.InnerText = "Type : ";
                            LblTmp1.InnerText = GameProfileData[0];
                            break;


                        case "Strategies":
                            lblTmp1Header.InnerText = "realtime : ";
                            string s = GameProfileData[0];
                            if (s.Equals("false"))
                            {
                                LblTmp1.InnerText = "Has No Real Time";
                            }
                            else
                            {
                                LblTmp1.InnerText = "Has Real Time";
                            }
                            break;

                        case "Rpgs":
                            lblTmp1Header.InnerText = "storyline : ";
                            LblTmp1.InnerText = GameProfileData[0];
                            lblTmp2Header.InnerText = "pvp : ";
                            string s1 = GameProfileData[1];
                            if (s1.Equals("False"))
                            {
                                LblTmp2.InnerText = "Provide no  Player Vs Player ability";
                            }
                            else
                            {
                                LblTmp2.InnerText = "Provide   Player Vs Player ability";
                            }

                            break;

                    }

                       string email =(string) Session["LoggedinMemberEmail"];
                 
                    bool check = controller.CheckIFLoggedInMemberRateGame(email, GameNme);
                    if (check)
                    {
                        string[] rates = controller.GetRatesRatedByMember(email, GameNme);
                        txtGraphics.Text = rates[0];
                        txtGraphics.Enabled = false;

                        txtInteractivity.Text = rates[1];
                        txtInteractivity.Enabled = false;

                        txtUniquness.Text = rates[2];
                        txtUniquness.Enabled = false;

                        txtLevelDesign.Text = rates[3];
                        txtLevelDesign.Enabled = false;

                        btnSaveRating.Text = "Edit your Ratings";
                        btnSaveRating.CommandName = "Edit";
                    }

                 

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
            try {
                getReviews();
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
        }



        protected void btnSaveRating_Command(object sender, CommandEventArgs e)
        {
            try {
                if (e.CommandName.Equals("Save"))
                {
                    string Graphics = txtGraphics.Text;
                    string interactivity = txtInteractivity.Text;
                    string uniquness = txtUniquness.Text;
                    string levelDesign = txtLevelDesign.Text;

                    string email = (string)Session["LoggedinMemberEmail"];
                    string GameNme = (string)Session["GameName"];

                    int RowsAffected = controller.SaveNewRatings(email, GameNme, Graphics, interactivity, uniquness, levelDesign);
                    if (RowsAffected == 1)
                    {
                        LblRatingStatus.Text = "Rating Saved";
                        txtGraphics.Enabled = false;
                        txtInteractivity.Enabled = false;
                        txtLevelDesign.Enabled = false;
                        txtUniquness.Enabled = false;
                        int result= controller.getAverageRateOFGame(GameNme);
                        LblRating.InnerText = result + "";
                    }
                }
                else
                {
                    if (e.CommandName.Equals("Edit"))
                    {

                        string email = (string)Session["LoggedinMemberEmail"];
                        string GameNme = (string)Session["GameName"];

                        string[] rates = controller.GetRatesRatedByMember(email, GameNme);
                        txtGraphics.Enabled = true;
                        txtInteractivity.Enabled = true;
                        txtUniquness.Enabled = true;
                        txtLevelDesign.Enabled = true;
                        txtGraphics.Text = rates[0];
                      

                            txtInteractivity.Text = rates[1];
                      

                            txtUniquness.Text = rates[2];
                       

                            txtLevelDesign.Text = rates[3];
                       

                            btnSaveRating.Text = "Save";
                            btnSaveRating.CommandName = "SaveEdits";
                    }else
                    {
                        if (e.CommandName.Equals("SaveEdits"))
                        {
                            string Graphics = txtGraphics.Text;
                            string interactivity = txtInteractivity.Text;
                            string uniquness = txtUniquness.Text;
                            string levelDesign = txtLevelDesign.Text;

                            string email = (string)Session["LoggedinMemberEmail"];
                            string GameNme = (string)Session["GameName"];

                            int RowsAffected = controller.updateMemberRatings(email, GameNme, Graphics, interactivity, uniquness, levelDesign);
                            if (RowsAffected == 1)
                            {
                                LblRatingStatus.Text = "Rating Saved";
                                txtGraphics.Enabled = false;
                                txtInteractivity.Enabled = false;
                                txtLevelDesign.Enabled = false;
                                txtUniquness.Enabled = false;
                                controller.getAverageRateOFGame(GameNme);
                            }
                        }
                    }
                }
            } 
            catch(Exception ex)
            {
                LblRatingStatus.Text = ex.Message;
            }
            }



        public void getReviews()
        {
            try
            {

                string GameNme = (string)Session["GameName"];
                List<string[]> outputList = controller.getAllGameReviews(GameNme);
                
                if (outputList.Count != 0)
                {
                    LblReviewsStatus.Text = "Reviews";
                    Table1.Visible = true;
                    int count = 0;
                    TableRow row = new TableRow();
                    Table1.Rows.Add(row);
                    row.Attributes.Add("style", "background-color:#1C5E55; border:2px solid Black; color:black ");

                    TableCell cell = new TableCell();
                    cell.Text = "Verified Reviewer";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    cell.Text = "Date of Creation";
                    row.Cells.Add(cell);

                    cell = new TableCell();
                    cell.Text = "Review Title";
                    row.Cells.Add(cell);

                   
                

                    foreach (string[] OutputRow in outputList)
                    {
                        row = new TableRow();
                        Table1.Rows.Add(row);
                        if (count % 2 == 0)
                        {
                            row.Attributes.Add("style", "background-color:#E3EAEB; border:2px solid Black; color:black ");

                        }
                        else
                        {
                            row.Attributes.Add("style", "background-color:White; border:2px solid Black; color:black ");

                        }
                      
                        for (int i = 0; i < 4; i++)
                        {
                            cell = new TableCell();
                            if (i == 0)
                            {
                                LinkButton LinkButton = new LinkButton();
                                LinkButton.Command += new CommandEventHandler(this.BtnShowProfile_Command);
                               // LinkButton.Command += this.BtnShowProfile_Command;
                                string email = OutputRow[i];
                                LinkButton.Text = email;
                                cell.Controls.Add(LinkButton);
                                LinkButton.CommandName = email;
                            
                            }
                            else
                            {
                                if (i == 2)
                                {

                                    LinkButton LinkButton = new LinkButton();
                                    LinkButton.Command += new CommandEventHandler(this.BtnShowReviews_Command);
                                  //  LinkButton.Command += this.BtnShowReviews_Command;
                                    string ReviewID = OutputRow[i];
                                    LinkButton.CommandName = ReviewID;
                                    i++;
                                    LinkButton.Text = OutputRow[i];
                                    cell.Controls.Add(LinkButton);
                                   

                                }
                                else
                                {
                                    cell.Text = OutputRow[i];
                                }
                            }
                            
                          
                            row.Cells.Add(cell);

                        }
                       

                    }
                }
              
            }
            catch (Exception ex)
            {
                LblReviewsStatus.Text = ex.Message;
            }


        }

        protected void BtnShowProfile_Command(object sender, CommandEventArgs e)
        {
        
            Session["MemberEmail"] = e.CommandName;
            Response.Redirect("~/Frontend Design/Vrefied Reviewer/NavigatingToVrifiedReviewerProfile.aspx");
        }

        protected void BtnShowReviews_Command(object sender, CommandEventArgs e)
        {
            string ID = e.CommandName;
            Session["ReviewID"] = ID;
            Response.Redirect("~/Frontend Design/Game/GameReview.aspx");
        }

        protected void btnAddReview_Click(object sender, EventArgs e)
        {
            fieldset.Visible = true;
         
        }

        protected void BtnAddNewReview_Click(object sender, EventArgs e)
        {
            string email = (string)Session["LoggedinMemberEmail"];
            string GameName = (string)Session["GameName"];
            string NewReviewTitle = txtTitle.Text;
            string newReviewContent = txtContent.InnerText;

            try
            {
                int check = controller.AddNewReview(GameName, email, newReviewContent, NewReviewTitle);
                if (check == 1)
                {
                    LblAddReviewStatus.Text = "Review is Added Successfully";
                }
            }
            catch (Exception ex)
            {
                LblAddReviewStatus.Text = ex.Message;
            }
        }
    }
}