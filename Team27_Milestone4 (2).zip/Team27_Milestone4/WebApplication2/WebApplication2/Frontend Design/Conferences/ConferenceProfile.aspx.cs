﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace WebApplication2.Frontend_Design.Conferences
{
    public partial class ConferenceProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("GetConference", conn);
            cmd.CommandType = CommandType.StoredProcedure;

              string ConferencesID = (string)Session["ConferencesID"];
          
            cmd.Parameters.Add(new SqlParameter("@id", ConferencesID));
            SqlCommand cmd2 = new SqlCommand("select  conference_review_id, (content) as reviews,member_email from Conference_Reviews where conference_id= '" + ConferencesID + "'", conn);

            SqlCommand cmd3 = new SqlCommand("sp_View_Conference", conn);
            cmd3.CommandType = CommandType.StoredProcedure;
            

            conn.Open();
            SqlDataReader rdr2 = cmd2.ExecuteReader();
            ReviewGridView.DataSource = rdr2;
            ReviewGridView.DataBind();
            conn.Close();
            conn.Open();

            cmd3.Parameters.Add(new SqlParameter("@id", ConferencesID));
            SqlDataReader rdr3 = cmd3.ExecuteReader();
            GridView1.DataSource = rdr3;
            GridView1.DataBind();
            conn.Close();
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    string ConferenceName = rdr.GetString(rdr.GetOrdinal("name"));
                    Session["ConferenceName"] = ConferenceName;

                    DateTime startdate = rdr.GetDateTime(rdr.GetOrdinal("start_date"));
                    String venue = rdr.GetString(rdr.GetOrdinal("venue"));
                    string date = "" + startdate;

                    lblConferenceName.InnerText = ConferenceName;
                    lblDate.InnerText = date;
                    lblLocation.InnerText = venue;



                }
            }
        }

        protected void btnAttendConference_Click(object sender, EventArgs e)
        {

            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("Add_Conferenceby_Members", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            string email = (string)Session["LoggedinMemberEmail"];
            string ConferencesID = (string)Session["ConferencesID"];
            cmd.Parameters.Add(new SqlParameter("@email", email));
            cmd.Parameters.Add(new SqlParameter("@conference_id", ConferencesID));
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception t)
            {
                Response.Write("you attended this conference before");
            }




        }

        protected void btnDevelopment_team_add_game_clik(object sender, EventArgs e)
        {

            AddGameDiv.Visible = true;
        }

        protected void btnAddReview_Click(object sender, EventArgs e)
        {
            Add_review_Conference.Visible = true;
        }

        protected void btnReview_Click(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("sp_add_conference_review_to_confernece_I_attended", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            string email = (string)Session["LoggedinMemberEmail"];
            string ConferencesName = (string)Session["ConferenceName"];

            cmd.Parameters.Add(new SqlParameter("@email", email));
            cmd.Parameters.Add(new SqlParameter("@conference_id", 2));
            cmd.Parameters.Add(new SqlParameter("@review", txtReviewContent.Value));
            conn.Open();
            cmd.ExecuteNonQuery();


        }





        protected void btnAdd_Game_Click(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["DBMS"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("sp_DevelopmentTeam_Add_Attended_Conference_and_Games", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@conferencename",Session["ConferenceName"]));
            cmd.Parameters.Add(new SqlParameter("@name", txtgame.Value));
            cmd.Parameters.Add(new SqlParameter("@email", Session["LoggedinMemberEmail"]));
            cmd.Parameters.Add(new SqlParameter("@releasedate", txtreleasedate.Value));
            cmd.Parameters.Add(new SqlParameter("@rating", txtRating.Value));
            cmd.Parameters.Add(new SqlParameter("@agelimit", TextAgeLimit.Value));
            cmd.Parameters.Add(new SqlParameter("@type", txttype.Value));

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        protected void ReviewGridView_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = ReviewGridView.SelectedRow;
            string conferenceID = row.Cells[1].Text;
            Session["ConferenceReviewID"] = conferenceID;
            Response.Redirect("~/Frontend Design/Conferences/ConferenceReview.aspx");


        }







        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            string conferenceID = row.Cells[6].Text;
            Session["GameName"] = conferenceID;
            Response.Redirect("~/Frontend Design/Game/GameProfile.aspx");
        }
    }
}