﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;

namespace WebApplication2.Frontend_Design.Development_Team
{
    public partial class NavigateToDevelopmentTeamProfile : System.Web.UI.Page
    {
        ProfileController controller;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                controller = new ProfileController();
                string email = (string)Session["MemberEmail"];
                string[] NormalUserProfileData = controller.GetDevelopmentTeamProfileData(email);
                lblTeamName.InnerText = NormalUserProfileData[0];
                LblCompany.InnerText = NormalUserProfileData[1];
                LblEmail.InnerText = NormalUserProfileData[2];
                LblMemberType.InnerText = NormalUserProfileData[3];
                LblFormationDate.InnerText = NormalUserProfileData[4];
                lblPreferedGameGenre.InnerText = NormalUserProfileData[5];

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListItem li = DropDownList1.SelectedItem;
            string MemberType = li.Text;
            switch (MemberType)
            {
                case "Normal Users": Response.Redirect("~/Frontend Design/Development Team/DNormalUserSearch.aspx"); break;
                case "Vrefied Reviewer": Response.Redirect("~/Frontend Design/Development Team/DVrefiedReviewersSearch.aspx"); break;
                case "Development Team": Response.Redirect("~/Frontend Design/Development Team/DDevelopmentTeamSearch.aspx"); break;
            }
        }
    }
}