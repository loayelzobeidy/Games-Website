﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;

namespace WebApplication2.Frontend_Design.Development_Team
{
    public partial class EditDevelopmentTeamInformations : System.Web.UI.Page
    {
        ProfileController controller = new ProfileController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
            {
               
                    string email = (string)Session["LoggedinMemberEmail"];
                    string[] NormalUserProfileData = controller.GetDevelopmentTeamProfileData(email);

                    txtTeamName.Text = NormalUserProfileData[0];
                    txtCompanyName.Text = NormalUserProfileData[1];
                    txtFormationDate.Text = NormalUserProfileData[4];
                    txtGameGenre.Text = NormalUserProfileData[5];
                    Session["Date"] = NormalUserProfileData[4];
                }
            catch (Exception ex)
            {
                LblStatus.Text = ex.Message;
            }
        }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string email = (string)Session["LoggedinMemberEmail"];
            string TeamName = txtTeamName.Text;
            string CompanyName = txtCompanyName.Text;
            string FormationDate = txtFormationDate.Text;
            if (string.IsNullOrEmpty(FormationDate))
            {
                FormationDate = (string)Session["Date"];
            }
            string GameGenre = txtGameGenre.Text;
            try
            {
                controller.UpdateDevelopmentTeamProfile(email, TeamName, CompanyName, FormationDate, GameGenre);
                Response.Redirect("~/Frontend Design/Development Team/WebFormDevelopmentTeamProfile.aspx");
            }
            catch (Exception ex)
            {
                LblStatus.Text = ex.Message;
            }
        }
    }
}