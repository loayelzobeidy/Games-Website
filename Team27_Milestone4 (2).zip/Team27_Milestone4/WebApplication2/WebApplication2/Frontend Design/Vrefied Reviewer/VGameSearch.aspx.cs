﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;
using System.Data;


namespace WebApplication2.Frontend_Design.Vrefied_Reviewer
{
    public partial class Search : System.Web.UI.Page
    {
        ProfileController controller = new ProfileController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    DataSet dataset = controller.GetAllGames();
                    GridView1.Visible = true;
                    GridView1.DataSource = dataset;
                    GridView1.DataBind();
                    lblSearchStatus.Text = "Resulting Games";
                }
                catch (Exception ex)
                {
                    GridView1.Visible = false;
                    lblSearchStatus.Text = ex.Message;
                }
            }
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e) // i remove the first coloumn then added it to the end 
        {

            TableCell cell = e.Row.Cells[0];
            e.Row.Cells.RemoveAt(0);

            e.Row.Cells.Add(cell);
          


        }

        protected void txtGameName_TextChanged(object sender, EventArgs e)
        {
            string SearchText = txtGameName.Text;
            try {
                DataSet dataset = controller.SearchForGame(SearchText);
                GridView1.Visible = true;
                GridView1.DataSource = dataset;
                GridView1.DataBind();
                lblSearchStatus.Text = "Resulting Games";

            } catch(Exception ex)
            {
                GridView1.Visible =false;
                lblSearchStatus.Text = ex.Message;   
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            string gameName = row.Cells[0].Text;

            Session["GameName"] = gameName;
            Response.Redirect("~/Frontend Design/Game/GameProfile.aspx");
        }
    }
}