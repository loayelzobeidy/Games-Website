﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;

namespace WebApplication2.Frontend_Design.Vrefied_Reviewer
{
    public partial class EditMyProfile : System.Web.UI.Page
    {
        ProfileController controller = new ProfileController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {

                    string email = (string)Session["LoggedinMemberEmail"];
                    string[] NormalUserProfileData = controller.GetVrefiedRevieweProfileData(email);

                    txtFirstName.Text = NormalUserProfileData[0];
                    txtLastName.Text = NormalUserProfileData[1];
                    txtBirthDate.Text = NormalUserProfileData[4];
                    txtGameGenre.Text = NormalUserProfileData[6];
                    Session["Date"] = NormalUserProfileData[4];
                }
                catch (Exception ex)
                {
                    LblStatus.Text = ex.Message;
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string email = (string)Session["LoggedinMemberEmail"];
            string FirstName = txtFirstName.Text;
            string LastName = txtLastName.Text;
            string date = txtBirthDate.Text;
            if (string.IsNullOrEmpty(date))
            {
                date =(string) Session["Date"];
            }
            string GameGenre = txtGameGenre.Text;
            try
            {
                controller.UpdateVrefiedUserProfile(email, FirstName, LastName, date, GameGenre);
                Response.Redirect("~/Frontend Design/Vrefied Reviewer/WebFormVrefiedReviewerProfile.aspx");
            }
            catch (Exception ex)
            {
                LblStatus.Text = ex.Message;
            }
        }
    }
}