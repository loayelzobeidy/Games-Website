﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;
namespace WebApplication2.Frontend_Design
{
    public partial class WebFormVrefiedReviewerProfile : System.Web.UI.Page
    {
        ProfileController controller;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                controller = new ProfileController();
                string email = (string)Session["LoggedinMemberEmail"];
                string[] NormalUserProfileData = controller.GetVrefiedRevieweProfileData(email);
                lblFirstName.InnerText = NormalUserProfileData[0];
                LblLastName.InnerText = NormalUserProfileData[1];
                LblEmail.InnerText = NormalUserProfileData[2];
                LblMemberType.InnerText = NormalUserProfileData[3];
                LblWorkingSince.InnerText = NormalUserProfileData[4];
                LblYearsOFExperience.InnerText = NormalUserProfileData[5];
                lblPreferedGameGenre.InnerText = NormalUserProfileData[6];
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void btnEditProfileData_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Frontend Design/Vrefied Reviewer/EditVrefiedUserProfile.aspx");
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListItem li = DropDownList1.SelectedItem;
            string MemberType = li.Text;
            switch (MemberType)
            {
                case "Normal Users": Response.Redirect("~/Frontend Design/Development Team/DNormalUserSearch.aspx"); break;
                case "Vrefied Reviewer": Response.Redirect("~/Frontend Design/Development Team/DVrefiedReviewersSearch.aspx"); break;
                case "Development Team": Response.Redirect("~/Frontend Design/Development Team/DDevelopmentTeamSearch.aspx"); break;
            }
        }
    }
}