﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication2.Controllers;


namespace WebApplication2.Frontend_Design
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        RegistraionController controller;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
        {

            if (Page.IsValid)
            {
                controller = new RegistraionController();
                LblRegistrationStatus.Text = "No registration validation Errors";
                LblRegistrationStatus.ForeColor = System.Drawing.Color.Green;

                string email = txtemail.Text;
                string password = txtpassword.Text;
                string EncryptedPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "SHA1");
                string genre = RadioButtonList1.SelectedValue;
                string type = (string)Session["type"];


                Response.Write(type);
                try
                {
                    controller.CheckForExsistingOfEmail(email);
                    controller.insertNewMember(email, EncryptedPassword, genre, type);

                    switch (type)
                    {

                        case "Normal User": controller.insertNewNormalUser(email, txt1.Text, txt2.Text, txt3.Text); break;
                        case "Verified Reviewer": controller.insertNewVrefiedReviewer(email, txt1.Text, txt2.Text, txt3.Text); break;
                        case "Development Team": controller.insertNewDevelopmentTeam(email, txt1.Text, txt2.Text, txt3.Text); break;
                    }

                }
                catch (Exception ex)
                {
                    LblRegistrationStatus.Text = ex.Message;
                    LblRegistrationStatus.ForeColor = System.Drawing.Color.Red;
                }


            }
            else
            {
                LblRegistrationStatus.Text = "Registration validation Errors";
                LblRegistrationStatus.ForeColor = System.Drawing.Color.Red;
            }
        }


        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SecondryData.Visible = true;
            string value = RadioButtonList2.SelectedValue;
            Session["type"] = value;
            if (value.Equals("Normal User"))
            {
                lblstatus.Text = "Normal User";
                lbl1.Text = "First Name";
                lbl2.Text = "Last Name";
                lbl3.Text = "Date Of Birth";
            }
            else
            {
                if (value.Equals("Verified Reviewer"))
                {
                    lblstatus.Text = "Verified Reviewer";
                    lbl1.Text = "First Name";
                    lbl2.Text = "Last Name";
                    lbl3.Text = "Working Since";
                    img3.ImageUrl = "../Images/calendar68.png";
                }
                else
                {
                    if (value.Equals("Development Team"))
                    {
                        lblstatus.Text = "Development Team";
                        lbl1.Text = "Team Name";
                        lbl2.Text = "Company Name";
                        lbl3.Text = "Formation Date";
                        img1.ImageUrl = "../Images/business53.png";
                        img2.ImageUrl = "../Images/businessman7.png";
                        img3.ImageUrl = "../Images/calendar68.png";
                    }
                }
            }
        }

        protected void btnLogin_Click(object sender, ImageClickEventArgs e)
        {
            controller = new RegistraionController();
            string email = txtLoginEmail.Text;
            string password = txtLoginPassword.Text;
            string EncryptedPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "SHA1");
            try {
                string memberType = controller.checkForVailedEmailAndPassword(email, EncryptedPassword);
                Session["LoggedinMemberEmail"] = email;
                Session["MemberType"] = memberType;
                switch (memberType)
                {
                    case "Normal User": Response.Redirect("~/Frontend Design/Normal User/WebFormProfile.aspx"); break;
                    case "Verified Reviewer": Response.Redirect("~/Frontend Design/Vrefied Reviewer/WebFormVrefiedReviewerProfile.aspx"); break;
                    case "Development Team": Response.Redirect("~/Frontend Design/Development Team/WebFormDevelopmentTeamProfile.aspx"); break;
                    default: Exception ex = new Exception("Unkown Member Type"); throw ex;
                }
               
            }
            catch(Exception ex)
            {
                LblRegistrationStatus.Text = ex.Message;
            } 
         }
    }
}