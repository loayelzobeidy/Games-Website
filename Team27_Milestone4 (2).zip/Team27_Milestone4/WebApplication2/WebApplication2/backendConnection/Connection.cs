﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using WebApplication2.Exceptions;

namespace WebApplication2.backendConnection
{
    public class Connection
    {
        SqlConnection connection;

        public Connection()
        {
            String connectionString = ConfigurationManager.ConnectionStrings["DBMS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

        public int ExcecuteNonQuery(SqlCommand command)
        {
            try
            {
                connection.Open();
                int rowAffected = command.ExecuteNonQuery();
                if (rowAffected == 0)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }


        public object ExcecuteScaler(SqlCommand command)
        {
            try
            {
                connection.Open();
                object output = command.ExecuteScalar();
                return output;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataSet DataAdapterReader (SqlCommand command,string TableName)
        {
            try {
                connection.Open();
                SqlDataAdapter SDA = new SqlDataAdapter(command);
                DataSet dataset = new DataSet();
                SDA.Fill(dataset, TableName);

                

                return dataset;
            } catch(Exception e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        public string []  ExcecuteReader (SqlCommand command , int OutputArraySize)
        {

            try
            {
                string[] OutputArray = new string[OutputArraySize];
                connection.Open();

                using (SqlDataReader SqlDataReader = command.ExecuteReader())
                {

                    if (SqlDataReader.HasRows)
                    {
                        while (SqlDataReader.Read())
                        {
                            for (int i = 0; i < OutputArraySize; i++)
                            {
                                OutputArray[i] = SqlDataReader.GetValue(i).ToString();
                            }
                        }
                        return OutputArray;

                    
                }else{
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Data Found");
                    throw EmptyReturnedQueryException;
                }
            }
               

            }
            catch(Exception e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }


        public List<string[]> ExcecuteReaderReturnList(SqlCommand command, int rowSize)
        {

            try
            {
                
                connection.Open();
                List<string[]> OutputList = new List<string[]>();
                using (SqlDataReader SqlDataReader = command.ExecuteReader())
                {
                   

                    if (SqlDataReader.HasRows)
                    {
                        while (SqlDataReader.Read())
                        {
                            string[] Array = new string[rowSize];
                            for (int i = 0; i < rowSize; i++)
                            {
                                Array[i] = SqlDataReader.GetValue(i).ToString();
                            }
                            OutputList.Add(Array);
                        }
                       


                    }
                    return OutputList;
                }


            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }



        public SqlConnection getSqlConnection()
        {
            return connection;
        }
    }
}