﻿using System.Web.UI;

namespace WebApplication2.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}