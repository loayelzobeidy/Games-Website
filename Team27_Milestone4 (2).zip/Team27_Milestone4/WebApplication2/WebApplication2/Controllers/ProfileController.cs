﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication2.backendConnection;
using WebApplication2.Exceptions;
using System.Data;
using System.Data.SqlClient;


namespace WebApplication2.Controllers
{
    public class ProfileController
    {

        Connection connection;
        public ProfileController()
        {
            connection = new Connection();

        }


        public string[] GetNormalUserProfileData(string email)
        {


            SqlCommand command = new SqlCommand("sp_get_normal_user_Profile_data", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@email", email);

            try
            {
                string[] OutputArray = new string[7];
               OutputArray = connection.ExcecuteReader(command, 7);
                if (OutputArray.Length == 0)
                {
                    EmptyReturnedQueryException ex = new EmptyReturnedQueryException("Failed To Load Normal User Data");
                    throw ex;
                }
                else
                {

                    return OutputArray;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public string[] GetVrefiedRevieweProfileData(string email)
        {


            SqlCommand command = new SqlCommand("sp_get_vrefied_reviewer_Profile_data", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@email", email);

            try
            {
                string[] OutputArray = new string[7];
               OutputArray = connection.ExcecuteReader(command, 7);
                if (OutputArray.Length == 0)
                {
                    EmptyReturnedQueryException ex = new EmptyReturnedQueryException("Failed To Load Verified Reviewer Data");
                    throw ex;
                }
                else
                {

                    return OutputArray;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public string[] GetDevelopmentTeamProfileData(string email)
        {


            SqlCommand command = new SqlCommand("sp_get_development_team_Profile_data", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@email", email);

            try
            {
                string[] OutputArray = new string[6];
              OutputArray = connection.ExcecuteReader(command, 6);
                if (OutputArray.Length == 0)
                {
                    EmptyReturnedQueryException ex = new EmptyReturnedQueryException("Failed To Load Normal User Data");
                    throw ex;
                }
                else
                {

                    return OutputArray;
                }

           

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public DataSet getRecievedMessages(string email, string TableName)
        {
            try
            {

                SqlCommand command = new SqlCommand("sp_GetMessages", connection.getSqlConnection());
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@receiver_email", email);
                DataSet dataset = new DataSet(TableName);
               dataset = connection.DataAdapterReader(command, TableName);
                if (dataset.Tables[TableName].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("There Are no Messages To Display");
                    throw EmptyReturnedQueryException;
                }
                return dataset;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int SendMessage(string SenderEmail, string ReceiverEmail, DateTime MessageDate, string MessageText)
        {
            SqlCommand command = new SqlCommand("sp_insertNewMessage", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@sender_email", SenderEmail);
            command.Parameters.AddWithValue("@reciever_email", ReceiverEmail);
            command.Parameters.AddWithValue("@message_date", MessageDate);
            command.Parameters.AddWithValue("@message_text", MessageText);
            try
            {
                int result = connection.ExcecuteNonQuery(command);
                if (result == 0)
                {
                    TransactionFailedException InsertionFailedException = new TransactionFailedException("Sending Message Failed Please try again");
                    throw InsertionFailedException;
                }
                return result;

            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public List<string [] > getListOfFriendsIadded(string email,string FriendType)
        {
            try
            {
                SqlCommand command; 
                if (FriendType.Equals("Added"))
                {
                  command  = new SqlCommand("sp_view_my_friend_list_I_added", connection.getSqlConnection());
                }
                else
                {
                    command = new SqlCommand("sp_view_my_friend_list_I_accepted", connection.getSqlConnection());
                }
                    command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@email", email);
                List<string[]> returnedList = new List<string[]>();
                 returnedList = connection.ExcecuteReaderReturnList(command, 3);
                if (returnedList.Count == 0)
                {
                    EmptyReturnedQueryException ex = new EmptyReturnedQueryException("No Friends Availabe");
                    throw ex;
                }
                else
                {
                    return returnedList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void removeFriend(string MyEmail, string unfriendEmail)
        {
            try
            {
                string query = "delete from Normal_Users_add_friend_Normal_Users  where (Requesting_email = '"+ MyEmail + "' and Receiving_email = '"+unfriendEmail+"') or  (Requesting_email = '"+ unfriendEmail+"' and Receiving_email = '"+MyEmail+"')";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int rowsAffected = connection.ExcecuteNonQuery(command);

                if (rowsAffected == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Removing Your Friend Failed Please try again");
                    throw EmptyReturnedQueryException;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public List<string[]> getFriendRequests(string email)
        {
            try {
                string sqlQuery = "select nu.first_name,nu.last_name,nu.normal_user_email from Normal_Users_add_friend_Normal_Users f inner join Normal_Users nu on f.Requesting_email = nu.normal_user_email where f.accept is null and Receiving_email='"+ email+"'";
                SqlCommand command = new SqlCommand(sqlQuery, connection.getSqlConnection());
                List<string[]> ListReturned = new List<string[]>();
               ListReturned = connection.ExcecuteReaderReturnList(command, 3);
                if(ListReturned.Count ==0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Friend Requests");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ListReturned;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            

        }

        public int AcceptFriend(string RequestingEmail, string ReceivingEmail) 
        {
            try {
                string query = "update Normal_Users_add_friend_Normal_Users set accept=1  where Receiving_email= '" + ReceivingEmail + "' and Requesting_email = '" + RequestingEmail + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int RowAffected = connection.ExcecuteNonQuery(command);
                if(RowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Accepting Friend Request Failed Please try again");
                    throw e;
                }
                else
                {
                    return RowAffected;
                }
              
                    }
            catch (Exception e) {
                throw e;
            }

        }


        public int RejectFriend(string RequestingEmail, string ReceivingEmail)
        {
            try
            {
                string query = "update Normal_Users_add_friend_Normal_Users set accept=0  where Receiving_email= '" + ReceivingEmail + "' and Requesting_email = '" + RequestingEmail + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int RowAffected = connection.ExcecuteNonQuery(command);
                if (RowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Rejecting Friend Request Failed Please try again");
                    throw e;
                }
                else
                {
                    return RowAffected;
                }

            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public void UpdateNormalUserProfile (string email,string FirstName,string LastName,string date,string GameGenre)
        {
            try {
                DateTime d = Convert.ToDateTime(date);
                string query = "update Normal_Users set first_name='" + FirstName + "' , last_name='" + LastName + "' , date_of_birth='" + d + "' where normal_user_email = '" + email + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int rowAffected = connection.ExcecuteNonQuery(command);
                if (rowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Updating Profile Informations Failed Please try again");
                    throw e;
                }

                query = "update Members set preferred_game_genre ='" + GameGenre + "' where email = '" + email + "'";
                command = new SqlCommand(query, connection.getSqlConnection());
                rowAffected = connection.ExcecuteNonQuery(command);
                if(rowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Updating Profile Informations Failed Please try again");
                    throw e;
                }
            } 
            catch(Exception ex)
            {
                throw ex;
            }
        }


        public void UpdateVrefiedUserProfile(string email, string FirstName, string LastName, string date, string GameGenre)
        {
            try
            {
                DateTime d = Convert.ToDateTime(date);
                string query = "update Verified_Reviewers set first_name='" + FirstName + "' , last_name='" + LastName + "' , Working_Since_year='" + d + "' where email = '" + email + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int rowAffected = connection.ExcecuteNonQuery(command);
                if (rowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Updating Profile Informations Failed Please try again");
                    throw e;
                }

                query = "update Members set preferred_game_genre ='" + GameGenre + "' where email = '" + email + "'";
                command = new SqlCommand(query, connection.getSqlConnection());
                rowAffected = connection.ExcecuteNonQuery(command);
                if (rowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Updating Profile Informations Failed Please try again");
                    throw e;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateDevelopmentTeamProfile(string email, string TeamName, string CompanyName, string FormationDate, string GameGenre)
        {
            try
            {
                DateTime d = Convert.ToDateTime(FormationDate);
                string query = "update Development_Teams set team_name='" + TeamName + "' , company='" + CompanyName + "' , formation_date='" + d + "' where email = '" + email + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int rowAffected = connection.ExcecuteNonQuery(command);
                if (rowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Updating Profile Informations Failed Please try again");
                    throw e;
                }

                query = "update Members set preferred_game_genre ='" + GameGenre + "' where email = '" + email + "'";
                command = new SqlCommand(query, connection.getSqlConnection());
                rowAffected = connection.ExcecuteNonQuery(command);
                if (rowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Updating Profile Informations Failed Please try again");
                    throw e;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetAllGames()
        {
            string query = "select name,rating,game_type from Games";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                DataSet ds = new DataSet("AllGames");
             ds = connection.DataAdapterReader(command, "AllGames");
                if(ds.Tables["AllGames"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Loading Games Failed Please Try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public DataSet SearchForGame(string SearchText)
        {
            SqlCommand command = new SqlCommand("sp_search_for_game", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Game_Name", SearchText);
            try
            {
                DataSet ds = new DataSet("Games");
             ds = connection.DataAdapterReader(command, "Games");
                if (ds.Tables["Games"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Game with this Criteria");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        public DataSet GetAllCommunities()
        {
            string query = "select theme,name from Communities_New";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                DataSet ds = new DataSet("AllCommunities");
                ds = connection.DataAdapterReader(command, "AllCommunities");
                if (ds.Tables["AllCommunities"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Loading Communities Failed Please Try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet SearchForCommunity(string SearchText)
        {
            SqlCommand command = new SqlCommand("sp_search_for_community", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@theme", SearchText);
            try
            {
                DataSet ds = new DataSet("Communities");
                ds = connection.DataAdapterReader(command, "Communities");
                if (ds.Tables["Communities"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Communities with this Criteria");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet GetAllConferences()
        {
            string query = "select conference_id ,name,venue from Conferences";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                DataSet ds = new DataSet("AllConferences");
                ds = connection.DataAdapterReader(command, "AllConferences");
                if (ds.Tables["AllConferences"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Loading Conferences Failed Please Try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public DataSet SearchForConfernece(string SearchText)
        {
            SqlCommand command = new SqlCommand("sp_search_for_Conferences", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@name", SearchText);
            try
            {
                DataSet ds = new DataSet("Conferences");
                ds = connection.DataAdapterReader(command, "Conferences");
                if (ds.Tables["Conferences"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Conferences with this Criteria");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetAllDevelopmentTeams()
        {
            string query = "select email,team_name from Development_Teams";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                DataSet ds = new DataSet("Development_Teams");
                ds = connection.DataAdapterReader(command, "Development_Teams");
                if (ds.Tables["Development_Teams"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Loading Development Teams Failed Please Try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet SearchForDevelopmentTeams(string SearchText)
        {
            SqlCommand command = new SqlCommand("sp_search_by_name_for_Development_Teams", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@name", SearchText);
            try
            {
                DataSet ds = new DataSet("Development_Teams");
                ds = connection.DataAdapterReader(command, "Development_Teams");
                if (ds.Tables["Development_Teams"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Development Teams with this Criteria");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet GetAllVrefiedReviewers()
        {
            string query = "select email,first_name,last_name from Verified_Reviewers";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                DataSet ds = new DataSet("VrefiedReviewers");
                ds = connection.DataAdapterReader(command, "VrefiedReviewers");
                if (ds.Tables["VrefiedReviewers"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Loading Vrefied Reviewers Failed Please Try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet SearchForVrefiedReviewer(string SearchText)
        {
            SqlCommand command = new SqlCommand("sp_search_by_name_for_Verified_Reviewers ", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@first_name", SearchText);
            try
            {
                DataSet ds = new DataSet("VrefiedReviewers");
                ds = connection.DataAdapterReader(command, "VrefiedReviewers");
                if (ds.Tables["VrefiedReviewers"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Vrefied Reviewers with this Criteria");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetAllNormalUsers()
        {
            string query = "select normal_user_email,first_name,last_name  from Normal_Users";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                DataSet ds = new DataSet("NormalUsers");
                ds = connection.DataAdapterReader(command, "NormalUsers");
                if (ds.Tables["NormalUsers"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Loading Normal Users Failed Please Try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet SearchForNormalUsers(string SearchText)
        {
            SqlCommand command = new SqlCommand("sp_search_by_name_for_Normal_Users ", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@first_name", SearchText);
            try
            {
                DataSet ds = new DataSet("Normal_Users");
                ds = connection.DataAdapterReader(command, "Normal_Users");
                if (ds.Tables["Normal_Users"].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Normal Users with this Criteria");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}