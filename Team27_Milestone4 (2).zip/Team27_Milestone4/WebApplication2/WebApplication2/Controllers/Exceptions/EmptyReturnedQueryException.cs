﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Exceptions
{
    public class EmptyReturnedQueryException : Exception
    {
        public EmptyReturnedQueryException (string Message) : base(Message)
        {

        }
    }
}