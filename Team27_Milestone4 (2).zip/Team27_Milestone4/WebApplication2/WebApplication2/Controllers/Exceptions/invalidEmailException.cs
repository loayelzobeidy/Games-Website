﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Exceptions
{
    public class invalidEmailException : Exception
    {
        public invalidEmailException (String Message) : base(Message)
        {

        }
    }
}