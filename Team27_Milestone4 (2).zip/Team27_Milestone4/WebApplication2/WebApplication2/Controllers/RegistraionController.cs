﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using WebApplication2.backendConnection;
using WebApplication2.Exceptions;
namespace WebApplication2.Controllers
{
    public class RegistraionController
    {
        Connection connection;
        public RegistraionController()
        {
            connection = new Connection();

        }

        public void insertNewMember(string email, string Password, string genre, string Type)
        {
            try
            {
                SqlCommand command = new SqlCommand("sp_sign_up", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", Password);
            command.Parameters.AddWithValue("@genre", genre);
            command.Parameters.AddWithValue("@type", Type);
           
           int RowAffected= connection.ExcecuteNonQuery(command);
                if(RowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Registration Failed Please Try again");
                    throw e;
                }
            }catch(Exception e)
            {
                throw e;
            }
        }
        public void insertNewNormalUser(string email, string firstName, string LastName, string DateOfBirth)
        {

            try {
            SqlCommand command = new SqlCommand("add_normal_user", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@normal_user_email", email);
            command.Parameters.AddWithValue("@first_name", firstName);
            command.Parameters.AddWithValue("@last_name", LastName);
            SqlParameter pramDateOfBirth = new SqlParameter("@date_of_birth", DateOfBirth);
            pramDateOfBirth.SqlDbType = SqlDbType.DateTime;
            command.Parameters.Add(pramDateOfBirth);

           
                int RowAffected = connection.ExcecuteNonQuery(command);
                if (RowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Registration Failed Please Try again");
                    throw e;
                }
            }
            catch (Exception e)
            {
                throw e;
            }




        }

        public void insertNewVrefiedReviewer(string email, string firstName, string LastName, string years_of_experience)
        {
            try
            {
                SqlCommand command = new SqlCommand("add_vrefied_reviewer", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@first_name", firstName);
            command.Parameters.AddWithValue("@last_name", LastName);
            SqlParameter pramDateOfBirth = new SqlParameter("@Working_Since_year", years_of_experience);
            pramDateOfBirth.SqlDbType = SqlDbType.DateTime;
            command.Parameters.Add(pramDateOfBirth);

           
                int RowAffected = connection.ExcecuteNonQuery(command);
                if (RowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Registration Failed Please Try again");
                    throw e;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }


        public void insertNewDevelopmentTeam(string email, string team_name, string company, string formation_date)
        {
            try
            {
                SqlCommand command = new SqlCommand("add_development_team", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@team_name", team_name);
            command.Parameters.AddWithValue("@company", company);
            SqlParameter pramDateOfBirth = new SqlParameter("@formation_date", formation_date);
            pramDateOfBirth.SqlDbType = SqlDbType.DateTime;
            command.Parameters.Add(pramDateOfBirth);

           
                int RowAffected = connection.ExcecuteNonQuery(command);
                if (RowAffected == 0)
                {
                    TransactionFailedException e = new TransactionFailedException("Registration Failed Please Try again");
                    throw e;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public void CheckForExsistingOfEmail(string email) 
        {
            SqlCommand command = new SqlCommand("sp_CheckForExsistingEmail" ,  connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@email",email);
            try {
                int result =(int) connection.ExcecuteScaler(command);
                if (result > 0)
                {
                    invalidEmailException ex = new invalidEmailException("Mail used Before ");
                    throw ex;
                }
            }catch(Exception e)
            {
                throw e;
            }
        }


        public string checkForVailedEmailAndPassword(string email , string password)
        {
           SqlCommand command = new SqlCommand("sp_Check_for_valid_email_and_password", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);
            try
            {
                string memberType = (string) connection.ExcecuteScaler(command);
                if (string.IsNullOrEmpty(memberType))
                {
                    invalidEmailException exception = new invalidEmailException("Invalid Email/Password");
                    throw exception;
                }
                return memberType;
            }
             catch(Exception ex)
            {
                throw ex;
            }
        }

     
        

    }
}