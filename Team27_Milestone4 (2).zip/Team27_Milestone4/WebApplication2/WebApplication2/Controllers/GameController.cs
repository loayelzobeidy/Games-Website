﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using WebApplication2.backendConnection;
using WebApplication2.Exceptions;
namespace WebApplication2.Controllers
{
    public class GameController
    {
        Connection connection;
            public GameController()
        {
            connection = new Connection();
        }

        public string[] GetGameProfileData(string GameName)
        {

            string query = "select name,age_limit,development_team_email ,rating,release_date,game_type   from Games where name ='" + GameName + "'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());


            try
            {
                string[] OutputArray = connection.ExcecuteReader(command, 6);


                return OutputArray;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public string[] getSpecialGameprofileData(string GameName , string GameType)
        {

            try { 
            string query;

            SqlCommand command;
       

            string[] outputArray;
                switch (GameType)
                {
                    case "Action":
                        query = "select sub_genre  from Actions a inner join Games g on a.game_ID = g.game_id where g.name= '" + GameName + "'";
                        command = new SqlCommand(query, connection.getSqlConnection());
                        outputArray = connection.ExcecuteReader(command, 1);
                        return outputArray;

                    case "Sports":
                        query = "select type  from Sports a inner join Games g on a.game_ID = g.game_id where g.name= '" + GameName + "'";
                        command = new SqlCommand(query, connection.getSqlConnection());
                        outputArray = connection.ExcecuteReader(command, 1);
                        return outputArray;

                    case "Strategies":
                        query = "select realtime  from Strategies a inner join Games g on a.game_ID = g.game_id where g.name= '" + GameName + "'";
                        command = new SqlCommand(query, connection.getSqlConnection());
                        outputArray = connection.ExcecuteReader(command, 1);
                        return outputArray;

                    case "Rpgs":
                        query = "select storyline,pvp  from Rpgs a inner join Games g on a.game = g.game_id where g.name= '" + GameName + "'";
                        command = new SqlCommand(query, connection.getSqlConnection());
                        outputArray = connection.ExcecuteReader(command, 2);
                        return outputArray;

                    default: return null;

                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public bool CheckIFLoggedInMemberRateGame(string Mail, string gameName)
        {
            string query = "select count(*) from Rates r inner join Games g on r.game_id = g.game_id where g.name='" + gameName + "' and r.member_email = '" + Mail + "'";
            try {
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int result = (int)connection.ExcecuteScaler(command);
                if (result == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }catch(Exception ex)
            {
                throw ex;
            }
        }

        public string [] GetRatesRatedByMember(string email , string gameName)
        {
            string query = "select graphics,interactivity,uniqueness,level_design from Rates r inner join Games g on r.game_id = g.game_id where g.name='"+ gameName+"' and r.member_email = '"+ email+"'";
            try {
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                string[] returnedArray = connection.ExcecuteReader(command, 4);
                return returnedArray;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public int SaveNewRatings (string email, string gameName,string graphics, string interactivity, string uniqueness,string level_design)
        {
            try {
                string query = "select game_id from Games where name = '" + gameName + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int x = (int)connection.ExcecuteScaler(command);
                string game_id = x + "";

                query = "insert into Rates values ('" + game_id + "','" + graphics + "','" + level_design + "','" + interactivity + "','" + uniqueness + "','" + email + "')";
                command = new SqlCommand(query, connection.getSqlConnection());
                int RowsAffected = connection.ExcecuteNonQuery(command);
                if (RowsAffected == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Saving errors Failed please try again ");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return 1;
                }
            }catch(Exception ex)
            {
                throw ex;
            }
        }

        public int updateMemberRatings (string email, string gameName, string graphics, string interactivity, string uniqueness, string level_design)
        {
            try { 
            string query = "select game_id from Games where name = '" + gameName + "'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            int x = (int)connection.ExcecuteScaler(command);
            string game_id = x + "";

            query = "update Rates set graphics = '"+graphics+ "' , interactivity ='" + interactivity + "', level_design = '" + level_design + "', uniqueness = '" + uniqueness + "' where member_email = '" + email + "' and game_id = '" + game_id + "'";
            command = new SqlCommand(query, connection.getSqlConnection());
                int RowsAffected = connection.ExcecuteNonQuery(command);
                if (RowsAffected == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Saving errors Failed please try again ");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetAllGames( string TableName)
        {
            try
            {
                string query = "select name As 'Name',rating as 'Rate Of Game',game_type as 'Game Type' from Games";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                DataSet dataset = new DataSet(TableName);
                 dataset = connection.DataAdapterReader(command, TableName);
                if (dataset.Tables[TableName].Rows.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("There Are no Messages To Display");
                    throw EmptyReturnedQueryException;
                }
                return dataset;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int RecommendGame (string senderEmail , string RecceiverEmail,string GameName)
        {
            try
            {
                string query = "select game_id from Games where name = '" + GameName + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int x = (int)connection.ExcecuteScaler(command);
                string game_id = x + "";

                 query = "insert into Normal_Users_Recommended_Games_to_Normal_Users values ('" + senderEmail + "','" + RecceiverEmail + "','" + game_id + "')";
                command = new SqlCommand(query, connection.getSqlConnection());
                int RowsAffected = connection.ExcecuteNonQuery(command);
                if (RowsAffected == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Recommending Email Failed please try again ");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int getAverageRateOFGame(string GameName)
        {
            SqlCommand command = new SqlCommand("sp_get_average_rate_of_A_game", connection.getSqlConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@name", GameName);

            SqlParameter outputParameter = new SqlParameter();
            outputParameter.Direction = ParameterDirection.Output;
            outputParameter.SqlDbType = SqlDbType.Int;
            outputParameter.ParameterName = "@average";

            command.Parameters.Add(outputParameter);
            try
            {
                connection.ExcecuteNonQuery(command);
                int Result = int.Parse(outputParameter.Value.ToString());

                command = new SqlCommand("update Games set rating = '" + Result + "' where name='" + GameName + "'",connection.getSqlConnection());
               int RowsAffected= connection.ExcecuteNonQuery(command);
                if(RowsAffected == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Updating Rates Failed");
                    throw EmptyReturnedQueryException;
                }
                return Result;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public string[] getReviewData(string review,string GameName)
        {
            int reviewID = int.Parse(review);

            string query = "select g.name,r.verified_reviewer_emial,r.date,r.Title,r.content from Game_Reviews r inner join Games g on r.game_id = g.game_id where g.name = '"+ GameName+"' and r.game_review_id='"+ reviewID+"'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                string[] ReturnedArray = new string[5];
              ReturnedArray = connection.ExcecuteReader(command,5);
                if (ReturnedArray.Length == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Review is not availabe");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ReturnedArray;
                }  

            }
            catch(Exception e)
            {
                throw e;
            }
        }

        public List<string []> getCommentsOnReview (string review)
        {
            int reviewID = int.Parse(review);

            string query = "select member_email,comment ,comment_id from Game_Review_Comments where  game_review_id='" + reviewID + "'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                List<string[]> returnedList = new List<string[]>();
               returnedList =  connection.ExcecuteReaderReturnList(command, 3);
                if(returnedList.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Comments Written On This Review");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return returnedList;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public int AddComment(string review, string GameName, string Email, string Content)
        {
            int reviewID = int.Parse(review);

            string query = "select game_id from Games where name = '" + GameName + "'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            int x = (int)connection.ExcecuteScaler(command);
            string gameID = x + "";

             query = "insert Game_Review_Comments values('"+ reviewID+ "','" + gameID + "','" + Email + "','" + Content + "')";
             command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
               int rowAffected =  connection.ExcecuteNonQuery(command);
                if(rowAffected == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("Adding comment on this review failed Please try again");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return rowAffected;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public List<string []> getAllGameReviews (string GameName)
        {
            string query = "select game_id from Games where name = '" + GameName + "'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            int x = (int)connection.ExcecuteScaler(command);
            string gameID = x + "";
            
            query = " select verified_reviewer_emial ,date, game_review_id ,Title from Game_Reviews where game_id = '" + gameID+"'";
            command = new SqlCommand(query, connection.getSqlConnection());
            try
            {
                List<string[]> ReturnedList = new List<string[]>();
           
               ReturnedList = connection.ExcecuteReaderReturnList(command, 4);
                if(ReturnedList.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Reviews on this Game");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ReturnedList;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public int AddNewReview (string gameName,string Email ,string content,string title)
        {
            try {
                string query = "select game_id from Games where name = '" + gameName + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int x = (int)connection.ExcecuteScaler(command);
                string gameID = x + "";

                DateTime date = DateTime.Now;

                query = "insert Game_Reviews values ('" + gameID + "','" + Email + "','" + date + "','" + content + "','" + title + "')";
                command = new SqlCommand(query, connection.getSqlConnection());
                int RowsAffected = connection.ExcecuteNonQuery(command);
                if(RowsAffected == 0)
                {
                    TransactionFailedException TransactionFailedException = new TransactionFailedException("Adding a Game Review Failed Please try again");
                    throw TransactionFailedException;
                }
                else
                {
                    return RowsAffected;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public int DeleteCommentOnReview(string commentID)
        {
            string query = "Delete from Game_Review_Comments where comment_id='" + commentID + "'";
            SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
            try {
                int rowsAffected = connection.ExcecuteNonQuery(command);
                if (rowsAffected == 0)
                {
                    TransactionFailedException TransactionFailedException = new TransactionFailedException("Deleting comment Failed Please try again");
                    throw TransactionFailedException;
                }
                else
                {
                    return rowsAffected;
                }
        }
            catch(Exception ex)
            {
                throw ex;
            }
            }

        public int AddScreenShot (string GameName , string ImageName)
        {
            try {
                string query = "select game_id from Games where name = '" + GameName + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int x = (int)connection.ExcecuteScaler(command);
                string gameID = x + "";

                DateTime date = DateTime.Now;
                query = "insert into Screenshots values('" + gameID + "','" + ImageName + "','" + date + "')";
                command = new SqlCommand(query, connection.getSqlConnection());
                int rowsAffected = connection.ExcecuteNonQuery(command);
                if (rowsAffected == 0)
                {
                    TransactionFailedException TransactionFailedException = new TransactionFailedException("Uploading ScreenShot Failed Please try again");
                    throw TransactionFailedException;
                }
                else
                {
                    return rowsAffected;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }



        }

        public List<string[]> GetScreenShotsPath (string gameName )
        {

            try {
                string query = "select game_id from Games where name = '" + gameName + "'";
                SqlCommand command = new SqlCommand(query, connection.getSqlConnection());
                int x = (int)connection.ExcecuteScaler(command);
                string gameID = x + "";

                query = "select screenshot_data from Screenshots where game_id = '" + gameID + "'";
                command = new SqlCommand(query, connection.getSqlConnection());

                List<string[]> ReturnedList = new List<string[]>();

                ReturnedList = connection.ExcecuteReaderReturnList(command, 1);
                if (ReturnedList.Count == 0)
                {
                    EmptyReturnedQueryException EmptyReturnedQueryException = new EmptyReturnedQueryException("No Screenshots on this Game");
                    throw EmptyReturnedQueryException;
                }
                else
                {
                    return ReturnedList;
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}